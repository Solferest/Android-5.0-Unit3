package com.example.heroapplication.model
import com.example.heroapplication.R

object HeroRep {
    val heroes = listOf(
        Hero(
            nameResource = R.string.hero1,
            descriptionResource = R.string.description1,
            imageResource = R.drawable.android_superhero1
        ),
        Hero(
            nameResource = R.string.hero2,
            descriptionResource = R.string.description2,
            imageResource = R.drawable.android_superhero2
        ),
        Hero(
            nameResource = R.string.hero3,
            descriptionResource = R.string.description3,
            imageResource = R.drawable.android_superhero3
        ),
        Hero(
            nameResource = R.string.hero4,
            descriptionResource = R.string.description4,
            imageResource = R.drawable.android_superhero4
        ),
        Hero(
            nameResource = R.string.hero5,
            descriptionResource = R.string.description5,
            imageResource = R.drawable.android_superhero5
        ),
        Hero(
            nameResource = R.string.hero6,
            descriptionResource = R.string.description6,
            imageResource = R.drawable.android_superhero6
        )
    )
}