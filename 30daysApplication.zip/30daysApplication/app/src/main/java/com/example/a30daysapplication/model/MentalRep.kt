package com.example.a30daysapplication.model
import com.example.a30daysapplication.R

object MentalRep {
    val mentalTips = listOf(
        MentalTip(
            nameRes = R.string.tip_1,
            instructionRes = R.string.tip_1_d,
            imageRes = R.drawable.tip_1_image,
        ),
        MentalTip(
            nameRes = R.string.tip_2,
            instructionRes = R.string.tip_2_d,
            imageRes = R.drawable.tip_2_image,
        ),
        MentalTip(
            nameRes = R.string.tip_3,
            instructionRes = R.string.tip_3_d,
            imageRes = R.drawable.tip_3_image,
        ),
        MentalTip(
            nameRes = R.string.tip_4,
            instructionRes = R.string.tip_4_d,
            imageRes = R.drawable.tip_4_image,
        ),
        MentalTip(
            nameRes = R.string.tip_5,
            instructionRes = R.string.tip_5_d,
            imageRes = R.drawable.tip_5_image,
        ),
        MentalTip(
            nameRes = R.string.tip_6,
            instructionRes = R.string.tip_6_d,
            imageRes = R.drawable.tip_6_image,
        ),
    )


}