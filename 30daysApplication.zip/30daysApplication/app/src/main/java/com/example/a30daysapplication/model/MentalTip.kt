package com.example.a30daysapplication.model

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

data class MentalTip(
    @StringRes val nameRes: Int,
    @StringRes val instructionRes: Int,
    @DrawableRes val imageRes: Int,
)
